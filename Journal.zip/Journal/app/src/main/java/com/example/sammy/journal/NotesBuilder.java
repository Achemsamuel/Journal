package com.example.sammy.journal;

import android.arch.persistence.room.Entity;
import android.arch.persistence.room.PrimaryKey;

import java.util.Date;

@Entity (tableName = "task")
public class NotesBuilder {

    @PrimaryKey (autoGenerate = true)
    private String title;
    private String content;
    private Date updatedAt;


    public NotesBuilder() {
    }

    public NotesBuilder (String title, String content, Date updatedAt) {
        this.title = title;
        this.content = content;
        this.updatedAt = updatedAt;
    }

    public String getTitle() {
        return title;
    }
    public void setTitle (String title) {this.title = title;}

    public String getContent() {
        return content;
    }
    public void setContent (String content) {this.content=content;}

    public Date getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt (Date updatedAt) { this.updatedAt = updatedAt; }



}
